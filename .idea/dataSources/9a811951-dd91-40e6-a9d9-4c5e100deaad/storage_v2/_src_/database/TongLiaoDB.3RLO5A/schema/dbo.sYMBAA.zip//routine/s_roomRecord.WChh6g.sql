-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[s_roomRecord]
	-- Add the parameters for the stored procedure here
	@uid INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT a.*,b.nickname AS n0,c.nickname AS n1,d.nickname AS n2,e.nickname AS n3,f.nickname AS n4,g.nickname AS n5 FROM dbo.roomRecord a  LEFT JOIN dbo.user_info b ON a.u0= b.userid LEFT JOIN dbo.user_info c ON a.u1=c.userid LEFT JOIN dbo.user_info d ON a.u2=d.userid 
	LEFT JOIN dbo.user_info e ON a.u3=e.userid LEFT JOIN dbo.user_info f ON a.u4=f.userid LEFT JOIN dbo.user_info g ON a.u5=g.userid WHERE a.u0=@uid OR a.u1=@uid OR a.u2=@uid OR a.u3=@uid OR a.u4=@uid OR a.u5=@uid
END
GO


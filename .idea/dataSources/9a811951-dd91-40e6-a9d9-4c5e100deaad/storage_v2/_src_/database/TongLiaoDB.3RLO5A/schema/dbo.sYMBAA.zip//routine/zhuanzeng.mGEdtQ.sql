-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[zhuanzeng]
	-- Add the parameters for the stored procedure here
	@wUid INT,
	@wZid INT,
	@wCard INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @uCard BIGINT
	DECLARE @zCard BIGINT

    -- Insert statements for procedure here
	IF(NOT EXISTS(SELECT * FROM dbo.user_info WHERE userid=@wUid))
	RETURN 1
	IF(NOT EXISTS(SELECT * FROM dbo.user_info WHERE userid=@wZid))
	RETURN 2
	UPDATE dbo.user_info SET card=card-@wCard WHERE userid=@wUid AND card - lockcard >=@wCard
	IF(@@ERROR=0 AND @@ROWCOUNT=1)
	BEGIN
		UPDATE dbo.user_info SET card=card+@wCard WHERE userid=@wZid
		SELECT @uCard=card FROM dbo.user_info WHERE userid=@wUid
		SELECT @zCard=card FROM dbo.user_info WHERE userid=@wZid
		SELECT @uCard AS uCard,@zCard AS zCard
		RETURN 0
	END
	ELSE 
	RETURN 3
END
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[s_gamerecord]

	-- Add the parameters for the stored procedure here
	@uuid VARCHAR(150)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT a.*,b.nickname AS n0,b.avatar AS a0,c.nickname AS n1,c.avatar AS a1,d.nickname AS n2,d.avatar AS a2,e.nickname AS n3,e.avatar AS a3,f.nickname AS n4,f.avatar AS a4,g.nickname AS n5,g.avatar AS a5 FROM dbo.roomRecord a  LEFT JOIN dbo.user_info b ON a.u0= b.userid LEFT JOIN dbo.user_info c ON a.u1=c.userid LEFT JOIN dbo.user_info d ON a.u2=d.userid 
	LEFT JOIN dbo.user_info e ON a.u3=e.userid LEFT JOIN dbo.user_info f ON a.u4=f.userid LEFT JOIN dbo.user_info g ON a.u5=g.userid WHERE a.uuid=@uuid
END
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cast] 
	-- Add the parameters for the stored procedure here
	@id INT,
	@cast INT
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @card BIGINT
	DECLARE @code INT

	UPDATE dbo.UserInfo SET card=card-@cast,lockcard=lockcard-@cast WHERE userid=@id AND card>=@cast AND lockcard>=@cast;
	IF(@@ERROR=0 AND @@ROWCOUNT=1)
		BEGIN
			SELECT @card=card FROM dbo.UserInfo WHERE userid=@id;
			SELECT @card AS card;
			RETURN 0;
		END
	ELSE
		RETURN -1;
END
GO


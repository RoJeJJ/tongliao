-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[lockCard] 
	-- Add the parameters for the stored procedure here
	@id INT,
	@card BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF(EXISTS(SELECT * FROM dbo.UserInfo WHERE userid=@id))
	BEGIN
		UPDATE dbo.UserInfo SET lockcard=lockcard+@card WHERE userid=@id AND card>=@card;
		IF(@@ERROR=0 AND @@ROWCOUNT=1)
			RETURN 0;
	END
	RETURN 1;
END
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VerifyAccounts]
	-- Add the parameters for the stored procedure here
	@wOpenid NVARCHAR(MAX),
	@wNickname NVARCHAR(50),
	@wSex TINYINT,
	@wCountry NVARCHAR(50),
	@wProvince NVARCHAR(50),
	@wCity NVARCHAR(50),
	@wLanguage NVARCHAR(50),
	@wHeadimgurl NVARCHAR(MAX),
	@wUnionid NVARCHAR(50),
	@wIp NVARCHAR(33)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @wUserID INT
	DECLARE @regGrantCard BIGINT
	DECLARE @state INT
    -- Insert statements for procedure here
	SELECT @state = StatusValue FROM SystemStatusInfo WHERE StatusName = 'LoginEnable';
	IF (@state = 1)
		RETURN 1;
	IF NOT EXISTS (SELECT userid FROM UserInfo WHERE openid = @wOpenid)
		BEGIN
			SELECT @regGrantCard = StatusValue FROM dbo.SystemStatusInfo WHERE StatusName = N'GrantCardCount'
			INSERT INTO dbo.UserInfo
			        ( openid ,
			          nickname ,
			          sex ,
					  country,
					  province,
					  city,
					  language,
			          headimgurl ,
			          ip ,
					  card,
			          lockcard ,
					  unionid,
					  LogedIn,
			          RegisterDate ,
			          LastLogonDate ,
			          LastLogoutDate ,
			          ShareDate
			        )
			VALUES  ( @wOpenid , 
			          @wNickname , 
			          @wSex , 
			          @wCountry ,
					  @wProvince,
					  @wCity,
					  @wLanguage,
					  @wHeadimgurl,
			          @wIP ,
					  @regGrantCard,
			          0 ,
					  @wUnionid,
					  0,
			          GETDATE() , 
			          NULL ,
			          NULL ,
			          NULL  
			        )
		END
	ELSE
		BEGIN
			UPDATE dbo.UserInfo SET nickname = @wNickname,sex = @wSex,country = @wCountry,province = @wProvince,city = @wCity,
			language = @wLanguage,headimgurl=@wHeadimgurl,ip=@wIp  WHERE openid = @wOpenid
		END

	DECLARE @UserID INT
	DECLARE @Nickname NVARCHAR(50)
	DECLARE @Sex TINYINT
	DECLARE @FaceUrl NVARCHAR(MAX)
	DECLARE @IP NVARCHAR(33)
	DECLARE @Nullity TINYINT
	DECLARE @card BIGINT


	SELECT @UserID=UserID,@Nickname=nickname,@Sex=sex,@FaceUrl=headimgurl,@IP=ip,@Nullity=Nullity,@card=card FROM dbo.UserInfo WHERE openid = @wOpenid
	IF (@Nullity = 1)
		RETURN 2;
	SELECT @UserID AS userid,@Nickname AS nickname,@sex AS sex,@FaceUrl AS faceurl,@IP AS ip,@card AS card
	RETURN 0;
END
GO
